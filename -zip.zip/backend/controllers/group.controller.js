import prisma from '../config/db.js';

// @desc    Create a study group
// @route   POST /api/groups
// @access  Private
export const createGroup = async (req, res) => {
  const { name, description, subject } = req.body;

  try {
    const group = await prisma.group.create({
      data: {
        name,
        description,
        subject,
        creator: { connect: { id: req.user.id } },
        members: { connect: { id: req.user.id } }, // Creator is automatically a member
      },
    });

    res.status(201).json(group);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get all study groups
// @route   GET /api/groups
// @access  Private
export const getGroups = async (req, res) => {
  try {
    const groups = await prisma.group.findMany({
      include: {
        members: {
          select: { id: true, name: true, role: true }
        },
        creator: {
          select: { name: true }
        }
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json(groups);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Join a study group
// @route   POST /api/groups/:id/join
// @access  Private
export const joinGroup = async (req, res) => {
  const { id } = req.params;

  try {
    const group = await prisma.group.findUnique({
      where: { id },
      include: { members: true },
    });

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const isMember = group.members.some(member => member.id === req.user.id);

    if (isMember) {
      return res.status(400).json({ message: 'You are already a member of this group' });
    }

    const updatedGroup = await prisma.group.update({
      where: { id },
      data: {
        members: {
          connect: { id: req.user.id },
        },
      },
    });

    res.json(updatedGroup);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
