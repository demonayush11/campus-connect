import prisma from '../config/db.js';

// @desc    Create a mentorship session
// @route   POST /api/mentors/sessions
// @access  Private (Mentor/Alumni only)
export const createSession = async (req, res) => {
  const { title, description, date, duration, link } = req.body;

  try {
    const session = await prisma.session.create({
      data: {
        title,
        description,
        date: new Date(date),
        duration: parseInt(duration),
        link,
        mentor: { connect: { id: req.user.id } },
      },
    });

    res.status(201).json(session);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Get all mentorship sessions
// @route   GET /api/mentors/sessions
// @access  Private
export const getSessions = async (req, res) => {
  try {
    const sessions = await prisma.session.findMany({
      include: {
        mentor: {
          select: { name: true, role: true, department: true },
        },
        attendees: {
          select: { id: true, name: true }, // Optional: show attendees
        }
      },
      orderBy: { date: 'asc' },
    });

    res.json(sessions);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// @desc    Join a mentorship session
// @route   POST /api/mentors/sessions/:id/join
// @access  Private
export const joinSession = async (req, res) => {
  const { id } = req.params;

  try {
    const session = await prisma.session.findUnique({
      where: { id },
      include: { attendees: true },
    });

    if (!session) {
      return res.status(404).json({ message: 'Session not found' });
    }

    // Check if user is already attending
    const isAttending = session.attendees.some(attendee => attendee.id === req.user.id);

    if (isAttending) {
      return res.status(400).json({ message: 'You have already joined this session' });
    }

    const updatedSession = await prisma.session.update({
      where: { id },
      data: {
        attendees: {
          connect: { id: req.user.id },
        },
      },
    });

    res.json(updatedSession);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
