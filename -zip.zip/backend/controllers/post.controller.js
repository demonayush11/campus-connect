import prisma from '../config/db.js';

// @desc    Create a new post
// @route   POST /api/posts
// @access  Private
export const createPost = async (req, res) => {
    const { title, content, tags } = req.body;

    try {
        const post = await prisma.post.create({
            data: {
                title,
                content,
                tags: tags || [],
                author: { connect: { id: req.user.id } },
            },
        });

        res.status(201).json(post);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Get all posts
// @route   GET /api/posts
// @access  Private
export const getPosts = async (req, res) => {
    try {
        const posts = await prisma.post.findMany({
            include: {
                author: {
                    select: { name: true, role: true, department: true }
                },
                comments: {
                    include: {
                        author: { select: { name: true, role: true } }
                    },
                    orderBy: { createdAt: 'asc' }
                }
            },
            orderBy: { createdAt: 'desc' },
        });

        res.json(posts);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Add a comment to a post
// @route   POST /api/posts/:id/comments
// @access  Private
export const addComment = async (req, res) => {
    const { id } = req.params;
    const { content } = req.body;

    try {
        const post = await prisma.post.findUnique({ where: { id } });

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        const comment = await prisma.comment.create({
            data: {
                content,
                post: { connect: { id } },
                author: { connect: { id: req.user.id } },
            },
            include: {
                author: { select: { name: true, role: true } }
            }
        });

        res.status(201).json(comment);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
