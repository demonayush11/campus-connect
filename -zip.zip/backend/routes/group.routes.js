import express from 'express';
import { createGroup, getGroups, joinGroup } from '../controllers/group.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

router.route('/')
    .get(protect, getGroups)
    .post(protect, createGroup);

router.post('/:id/join', protect, joinGroup);

export default router;
