import express from 'express';
import { createPost, getPosts, addComment } from '../controllers/post.controller.js';
import { protect } from '../middleware/auth.middleware.js';

const router = express.Router();

router.route('/')
    .get(protect, getPosts)
    .post(protect, createPost);

router.post('/:id/comments', protect, addComment);

export default router;
