import "dotenv/config"
import express from "express"
import cors from "cors"


import authRoutes from "./routes/auth.routes.js"
import mentorRoutes from "./routes/mentor.routes.js"
import groupRoutes from "./routes/group.routes.js"
import postRoutes from "./routes/post.routes.js"



const app = express()
app.use(cors())
app.use(express.json())

app.use("/api/auth", authRoutes)
app.use("/api/mentors", mentorRoutes)
app.use("/api/groups", groupRoutes)
app.use("/api/posts", postRoutes)

app.listen(5000, () => console.log("Server running on port 5000 🚀"))
