import "dotenv/config"
console.log("DB_URL:", process.env.DATABASE_URL)
